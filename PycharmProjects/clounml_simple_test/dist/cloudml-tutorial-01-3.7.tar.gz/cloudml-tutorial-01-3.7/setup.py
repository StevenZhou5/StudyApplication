#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import setuptools

setuptools.setup(name='cloudml-tutorial-01', version='3.7', packages=['trainer'])
