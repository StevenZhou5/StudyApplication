#!/usr/bin/python
# -*- coding: <encoding name> -*-
# （可选，用于项目代码的构建和分发）
import setuptools

setuptools.setup(name='cloudml-text-conv', version='3.7', author_emaol='zhouzhenwu@xiaomi.com', packages=['trainer'])
